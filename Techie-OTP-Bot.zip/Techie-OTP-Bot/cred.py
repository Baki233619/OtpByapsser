#Twilio Details

account_sid = 'ACe90eee1c6869a262e75c0759aa5eb179'
auth_token = 'cb8cb24936347954e7d24c862a1f5369'
twilionumber = '+19035825434'
twiliosmsnumber = '+19035825434'

#FC Bot
API_TOKEN = "7850930455:AAEQ5mMsMDOhrotQHftcm1WRqOwLazCnInA"

#Host URL
callurl = 'https://8a10-150-107-106-38.ngrok-free.app'
twiliosmsurl = 'https://8a10-150-107-106-38.ngrok-free.app/sms'









